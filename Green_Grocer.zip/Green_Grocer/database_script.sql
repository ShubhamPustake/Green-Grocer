use green_grocer;

create table Signup
(
user_id int auto_increment primary key,
Full_name nvarchar(45),
Username nvarchar(45),
Email nvarchar(45),
Contact bigint(10),
Address nvarchar(100),
Password nvarchar(45),
Confirm_password nvarchar(45),
Login_Type nvarchar(45),
date nvarchar(45)
);



create table Enquiry
(
enquiry_id int auto_increment primary key,
user_id int,
Username nvarchar(45),
Full_name nvarchar(45),
Email nvarchar(45),
Contact bigint(10),
Message nvarchar(100),
date nvarchar(45)
);

create table Feedback
(
Feedbck_id int auto_increment primary key,
Username nvarchar(45),
Email nvarchar(45),
Feedback_msg nvarchar(45)
);
create table product_stock
(
product_id int auto_increment primary key,
product_name nvarchar(45),
quantity int,
price int,
category nvarchar(45),
image nvarchar(100),
date nvarchar(100),
description nvarchar(300)
);

create table Product_order
(
Order_id int auto_increment primary key,
Product_id int,
user_id int,
Username nvarchar(45),
Product_name nvarchar(45),
Quantity int,
Price int,
Address nvarchar(45),
order_status nvarchar(45),
order_date nvarchar(45)
);

create table Address
(
Address_id int auto_increment primary key,
user_id int,
Username nvarchar(45),
Full_name nvarchar(45),
Contact  bigint(10),
Alternate_contact bigint(10),
House_no nvarchar(40),
Aera nvarchar(45)
);

create table Feedback
(
Feedback_id int auto_increment primary key,
User_id int,
Username nvarchar(45),
Email nvarchar(45),
Message nvarchar(100),
date nvarchar(45)
);

create table Payment
(
Payment_id int auto_increment primary key,
user_id int ,
Username nvarchar(45),
order_id int,
Pay_mode nvarchar(45),
payment_date nvarchar(45)
);

create table Supplier
(
Supplier_id int auto_increment primary key,
Supplier_name nvarchar(45),
Email nvarchar(45),
 Contact bigint(10),
 Address nvarchar(100)
);

create table Post_order
(
post_order_id int auto_increment primary key,
Supplier_name nvarchar(45),
product_name nvarchar(45),
category nvarchar(30),
quantity int,
order_status nvarchar(45),
date nvarchar(45)
);

create table cart
(
cart_id int auto_increment primary key,
user_id int,
product_id int,
product_name nvarchar(45),
price int,
category nvarchar(45),
quantity int,
total int,
image nvarchar(100),
date nvarchar(45)
);