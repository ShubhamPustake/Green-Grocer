/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class adminAddress extends HttpServlet {

    
       Connection cn=null;
     Statement st=null;
     
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out=resp.getWriter();
        
         String fullname = req.getParameter("fullname");
         String Contact = req.getParameter("Contact");
         String AlternateContact = req.getParameter("AlternateContact");
         String houseno = req.getParameter("houseno");
         String aera = req.getParameter("aera");
         
        out.println(fullname);
        out.println(Contact);
        out.println(AlternateContact);
        out.println(houseno);
        out.println(aera);
            
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
    }  
}
