/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class adminPostOrder extends HttpServlet {
       Connection cn=null;
       Statement st=null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
         PrintWriter out=resp.getWriter();
         
         String orderid = req.getParameter("orderid");
         String supplierid = req.getParameter("supplierid");
         String productname = req.getParameter("productname");
         String price = req.getParameter("price");
         String Category = req.getParameter("Category");
         String quantity = req.getParameter("quantity");
         String date = req.getParameter("date");
         String orderstatus = req.getParameter("orderstatus");
         String event=req.getParameter("submit");
         
        out.println(orderid);
        out.println(supplierid);
        out.println(productname);
        out.println(price);
        out.println(Category);
        out.println(quantity);
        out.println(date);
        out.println(orderstatus);
        out.println(event);
        
         Database db = new Database();
         String result = db.Connectdb();
         out.println(result);
    
          if(event.equals("Submit Data"))
          {
              if(orderid.equals("") || supplierid.equals("") || productname.equals("") ||price.equals("") || Category.equals("") || quantity.equals("") || date.equals("") || orderstatus.equals("") )
              {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='AdminPages/adminPostOrder.jsp'");
                 out.println("</script>");
              }
              else
              {
                  try
                  {
                      String sql="insert into post_order(order_id, supplier_id, product_name, price, category, quantity, order_date, order_status)values('"+orderid+"','"+supplierid+"','"+productname+"','"+price+"','"+Category+"','"+quantity+"','"+date+"','"+orderstatus+"')";
                      String insert=db.Insert(sql);
                      out.println(insert);
                      resp.setContentType("text/html");
                      out.println("<script type=\"text/javascript\">");
                      out.println("alert('Data Submitted Succesfully')");
                      out.println("location='AdminPages/adminPostOrder.jsp'");
                      out.println("</script>");
         }
         catch(Exception ex)
         {
             out.println(ex.toString());
         }
                  }
              }
             
          }
  }
 

