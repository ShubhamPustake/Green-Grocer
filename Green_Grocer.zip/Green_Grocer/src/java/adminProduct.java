/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class adminProduct extends HttpServlet {


       Connection cn=null;
     Statement st=null;
     
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out=resp.getWriter();
        
         String productid = req.getParameter("productid");
         String productname = req.getParameter("productname");
         String quantity = req.getParameter("quantity");
         String price = req.getParameter("price");
         String Category = req.getParameter("Category");
          String image = req.getParameter("image");
         String Date = req.getParameter("date");
         String Description = req.getParameter("Description");
         String event=req.getParameter("submit");
        
         
        out.println(productid);
        out.println(productname);
        out.println(quantity);
        out.println(price);
        out.println(Category);
         out.println(image);
        out.println(Date);
        out.println(Description);
        out.println(event);
            
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        
        if(event.equals("Add"))
        {
             
            if(productid.equals("") || productname.equals("") || quantity.equals("") ||price.equals("") || Category.equals("") || image.equals("") || Date.equals("") || Description.equals("") )
              {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='AdminPages/adminProduct.jsp'");
                 out.println("</script>");
              }
              else
              {
                 try
                 {
                     Class.forName("com.mysql.jdbc.Driver");
                    cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/green_grocer","root","root");
                    st=cn.createStatement();

                    String sql1="select * from product_stock where product_name = '"+productname+"' ";
                    ResultSet rs=st.executeQuery(sql1);

                    if(rs.next())
                    {
                        resp.setContentType("text/html");
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Product Already Present')");
                        out.println("location='AdminPages/adminProduct.jsp'");
                        out.println("</script>");
                    }
                    else
                    {
                        String sql= "insert into product_stock( product_id, product_name, quantity, price, category, image, date, description) values ('"+productid+"','"+productname+"','"+quantity+"','"+price+"','"+Category+"','"+image+"','"+Date+"','"+Description+"')" ;
                        String insert=db.Insert(sql);
                        out.println(insert);
                        resp.setContentType("text/html");
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Product Inserted')");
                        out.println("location='AdminPages/adminProduct.jsp'");
                        out.println("</script>");
                    }
                     
                 }
                 catch(Exception ex)
                 {
                   out.println(ex.toString());
                 }
              }
            }
        
        
        if(event.equals("Update"))
        {
            if(productid.equals("") || productname.equals("") || quantity.equals("") ||price.equals("") || Category.equals("") || image.equals("") || Date.equals("") || Description.equals("") )
              {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='AdminPages/adminProduct.jsp'");
                 out.println("</script>");
              }
              else
              {
                 try
                 {
                     String sql= "update product_stock set product_name='"+productname+"',quantity='"+quantity+"', price='"+price+"', category='"+Category+"', image='"+image+"', date='"+Date+"', description='"+Description+"' where product_id='"+productid+"'";
                     String update=db.update(sql);
                     out.println(update);
                     
                     resp.setContentType("text/html");
                     out.println("<script type=\"text/javascript\">");
                     out.println("alert('Product updated')");
                     out.println("location='AdminPages/adminProduct.jsp'");
                     out.println("</script>");
             
                 }
                 catch(Exception ex)
                 {
                   resp.setContentType("text/html");
                   out.println("<script type=\"text/javascript\">");
                   out.println("alert('"+ex.toString()+"')");
                   out.println("location='AdminPages/adminProduct.jsp'");
                  
                   out.println();
                 }
              }
            }
        
        
             if(event.equals("Delete"))
             {
                 try
                 {
                     String sql= "delete from product_stock where product_id='"+productid+"'";
                     String delete=db.delete(sql);
                     out.println(delete);
                     
                     resp.setContentType("text/html");
                     out.println("<script type=\"text/javascript\">");
                     out.println("alert('Product deleted')");
                     out.println("location='AdminPages/adminProduct.jsp'");
                     out.println("</script>");
             
                 }
                 catch(Exception ex)
                 {
                     out.println(ex.toString());
                 }
             }
   
    
    }
}
