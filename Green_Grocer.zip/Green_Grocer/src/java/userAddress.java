/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class userAddress extends HttpServlet {
     Connection cn=null;
     Statement st=null;
     
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out=resp.getWriter();
        
         String Fullname = req.getParameter("Fullname");
         String Contact = req.getParameter("Contact");
         String AlternateContact = req.getParameter("AlternateContact");
         String Houseno = req.getParameter("Houseno");
         String Aera = req.getParameter("Aera");
         String event=req.getParameter("submit");
         
        out.println(Fullname);
        out.println(Contact);
        out.println(AlternateContact);
        out.println(Houseno);
        out.println(Aera);
        out.println(event);
            
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        
        if(event.equals("Save Address"))
        {
            if(Fullname.equals("") || Contact.equals("") || AlternateContact.equals("") || Houseno.equals("") || Aera.equals(""))
            {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='UserPages/userAddress.jsp'");
                 out.println("</script>");
            }
            else
            {
                try
                {
                    String sql= "insert into address(  Full_name, Contact, Alternate_contact, House_no, Aera) values ('"+Fullname+"','"+Contact+"','"+AlternateContact+"','"+Houseno+"','"+Aera+"')" ;
                    String insert=db.Insert(sql);
                    out.println(insert);
                    
                   resp.setContentType("text/html");
                   out.println("<script type=\"text/javascript\">");
                   out.println("alert('Address Added Succesfully')");
                   out.println("location='UserPages/userPayment.jsp'");
                   out.println("</script>");
                }
               catch(Exception ex)
               {
                  out.println(ex.toString());
               }
            }
        }
        
    }

  
}
 