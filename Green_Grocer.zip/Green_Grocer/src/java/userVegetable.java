/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubzz
 */
public class userVegetable extends HttpServlet {

   
 
     Connection cn=null;
    Statement st=null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
         PrintWriter out=resp.getWriter();
         HttpSession session=req.getSession();
         
         String product_id=req.getParameter("product_id");
          String product_name=req.getParameter("product_name");
          String image=req.getParameter("image");
          String price=req.getParameter("price");
          String category=req.getParameter("category");
          int price1=100;
          
          out.println(product_id);
          out.println(product_name);
          out.println(image);
          out.println(price);
          out.println(category);
          
         String quantity = req.getParameter("quantity");    
         String event = req.getParameter("submit");
         
         out.println(quantity);
         out.println(event);
         
        
         
         out.println(quantity);
         out.println(event);
         
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
         if(event.equals("Add to Cart"))
        {
            if(quantity.equals(""))
            {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Please enter quantity you want to buy')");
                 out.println("location='UserPages/userVegetable.jsp'");
                 out.println("</script>");
            }
            else
            {
                String sql="insert into cart( user_id, product_id, product_name, price, category, quantity, image) values('"+session.getAttribute("user_id")+"','"+product_id+"','"+product_name+"','"+price1+"','"+category+"','"+quantity+"','"+image+"')";
                    String insert=db.Insert(sql);
                    out.println(insert);
         
                    resp.setContentType("text/html");
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert(' Product added succesfully to cart )");
                    out.println("location='UserPages/userVegetable.jsp'");
                    out.println("</script>");
            
            }
            }
        if(event.equals("submit"))
         {
             session.setAttribute("product_id",product_id);
             resp.sendRedirect("UserPages/userProduct.jsp");
         }
    }
}