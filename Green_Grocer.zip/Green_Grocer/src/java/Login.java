/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shubzz
 */
public class Login extends HttpServlet {
    
     Connection cn=null;
     Statement st=null;
      @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
        PrintWriter out=resp.getWriter();
        HttpSession session=req.getSession();
        
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String event=req.getParameter("submit");
        
        out.println(username);
        out.println(password);
        out.println(event);
        
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        if(event.equals("Login"))
        {
            if(username.equals("") || password.equals(""))
            {
                 resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert(' Something is empty')");
                           out.println("location='Login.jsp'");
                           out.println("</script>");
        
            }
            else
            {
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/green_grocer","root","root");
                    Statement st=cn.createStatement();
                    
                    String sql="select * from signup where (Username='"+username+"' || Email='"+username+"') && Password='"+password+"' ";
                    ResultSet rs=st.executeQuery(sql);
                    
                    if(rs.next())
                    {
                        if(rs.getString("Login_Type").toString().equals("admin"))
                        {
                           session.setAttribute("user_id",rs.getString("User_id"));
                           session.setAttribute("username",rs.getString("Username"));
                           session.setAttribute("contact",rs.getString("Contact"));
                           session.setAttribute("email",rs.getString("Email"));
                           
                           resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Login Succesful')");
                           out.println("location='AdminPages/adminHome.jsp'");
                           out.println("</script>");   
                        }
                        else if(rs.getString("Login_Type").toString().equals("user"))
                        {
                           session.setAttribute("user_id",rs.getString("User_id"));
                           session.setAttribute("username",rs.getString("Username"));
                           session.setAttribute("contact",rs.getString("Contact"));
                           session.setAttribute("email",rs.getString("Email"));
                           
                           resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Login Succesful')");
                           out.println("location='UserPages/userHome.jsp'");
                           out.println("</script>");
     
                        }
                    }
                    else
                    {
                         resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Incorrect Username or Password')");
                           out.println("location='Login.jsp'");
                           out.println("</script>");
        
                    }
                    
                }
                catch(Exception ex)
                      {
                          out.println(ex.toString());
                      }
                }
            }
     }
} 

