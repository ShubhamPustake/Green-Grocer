/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class userEnquiry extends HttpServlet {
    
     Connection cn=null;
    Statement st=null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out=resp.getWriter();
         
         String fullname = req.getParameter("fullname");
         String username = req.getParameter("username");
         String email = req.getParameter("email");
         String contact = req.getParameter("contact");
         String Message = req.getParameter("Message");
        
         String event=req.getParameter("submit");
         
        out.println(fullname);
        out.println(username);
        out.println(email);
        out.println(contact);
        out.println(Message);
        
        out.println(event);
        
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        
        if(event.equals("Do Enquiry"))
        {
            if(fullname.equals("") || username.equals("") || email.equals("")|| contact.equals("")||Message.equals(""))
            {
                  resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='UserPages/userEnquiry.jsp'");
                 out.println("</script>");
            }
            else
            {
                try
                {
                    String sql="insert into enquiry( Full_name, Username, Email, Contact, Message)values('"+fullname+"','"+username+"','"+email+"','"+contact+"','"+Message+"')";
                    String insert=db.Insert(sql);
                    out.println(sql);
                    resp.setContentType("text/html");
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Succesfully Submitted')");
                    out.println("location='UserPages/userHome.jsp'");
                    out.println("</script>");
            
                    
                }
                catch(Exception ex)
                {
                    out.println(ex.toString());
                }
            }
        }
    }

  
}
