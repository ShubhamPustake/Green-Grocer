/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class adminAddSupplier extends HttpServlet {
    
         Connection cn=null;
         Statement st=null;
      @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
        PrintWriter out=resp.getWriter();
        
        String supplierid=req.getParameter("supplierid");
        String suppliername=req.getParameter("suppliername");
        String email=req.getParameter("email");
         String contact=req.getParameter("contact");
        String address=req.getParameter("address");
        String event=req.getParameter("submit");
        
        out.println(supplierid);
        out.println(suppliername);
        out.println(email);
        out.println(contact);
        out.println(address);
        out.println(event);
        
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        
        if(event.equals("Add"))
        {
        if(suppliername.equals("") || email.equals("") || contact.equals("")  || address.equals(""))
        {
            resp.setContentType("text/html");
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Some fields are empty')");
            out.println("location='AdminPages/adminAddSupplier.jsp'");
            out.println("</script>");
        }
        else
        {
         try
         {
             String sql= "insert into supplier( Supplier_name, Email, Contact, Address) values ('"+suppliername+"','"+email+"','"+contact+"','"+address+"')" ;
             String insert=db.Insert(sql);
             out.println(insert);
             resp.setContentType("text/html");
             out.println("<script type=\"text/javascript\">");
             out.println("alert('Supplier Added Succesfully')");
             out.println("location='AdminPages/adminAddSupplier.jsp'");
             out.println("</script>");
         }
         catch(Exception ex)
         {
             out.println(ex.toString());
         }
        }      
    } 
        
         if(event.equals("Update"))
        {
            if(supplierid.equals("") || suppliername.equals("") || email.equals("") ||contact.equals("") || address.equals("")  )
              {
                 resp.setContentType("text/html");
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Some fields are empty')");
                 out.println("location='AdminPages/adminAddSupplier.jsp'");
                 out.println("</script>");
              }
              else
              {
                 try
                 {
                     String sql= "update supplier set Supplier_name='"+suppliername+"',Email='"+email+"', Contact='"+contact+"', Address='"+address+"' where supplier_id='"+supplierid+"' ";
                     String update=db.update(sql);
                     out.println(update);
                     
                     resp.setContentType("text/html");
                     out.println("<script type=\"text/javascript\">");
                     out.println("alert('Product updated')");
                     out.println("location='AdminPages/adminAddSupplier.jsp'");
                     out.println("</script>");
             
                 }
                 catch(Exception ex)
                 {
                   resp.setContentType("text/html");
                   out.println("<script type=\"text/javascript\">");
                   out.println("alert('"+ex.toString()+"')");
                   out.println("location='AdminPages/adminAddSupplier.jsp'");
                  
                   out.println();
                 }
              }
            }
        
        
             if(event.equals("Delete"))
             {
                 try
                 {
                     String sql= "delete from supplier where supplier_id='"+supplierid+"'";
                     String delete=db.delete(sql);
                     out.println(delete);
                     
                     resp.setContentType("text/html");
                     out.println("<script type=\"text/javascript\">");
                     out.println("alert('Supplier information deleted')");
                     out.println("location='AdminPages/adminAddSupplier.jsp'");
                     out.println("</script>");
             
                 }
                 catch(Exception ex)
                 {
                     out.println(ex.toString());
                 }
             }
   
    
  }
}