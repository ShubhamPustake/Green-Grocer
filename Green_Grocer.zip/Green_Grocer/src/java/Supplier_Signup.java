/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class Supplier_Signup extends HttpServlet {
    
      
        Connection cn=null;
        Statement st=null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
        String Login_Type="supplier";
         PrintWriter out=resp.getWriter();
        
             
         String fullname = req.getParameter("fullname");
         String username = req.getParameter("username");
         String email = req.getParameter("email");
         String contact = req.getParameter("contact");
         String address = req.getParameter("address");
         String password = req.getParameter("password");
         String confirmpassword = req.getParameter("confirmpassword");
         String event=req.getParameter("submit");
         
        out.println(fullname);
        out.println(username);
        out.println(email);
        out.println(contact);
        out.println(address);
        out.println(password);
        out.println(confirmpassword);
        out.println(event);
        
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        if(event.equals("Register"))
          {
              if(fullname.equals("") || username.equals("") || email.equals("") || contact.equals("") || address.equals("") || password.equals("") || confirmpassword.equals(""))
              {
                           resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Some fields are empty')");
                           out.println("location='Login.jsp'");
                           out.println("</script>");
                  
                 
              }
              else
              {
                  if(password.equals(confirmpassword))
                  {
                      try
                      {
                          String sql="insert into Signup(Full_name, Username, Email, Contact, Address, Password, Confirm_password,Login_Type) values('"+fullname+"','"+username+"','"+email+"','"+contact+"','"+address+"','"+password+"','"+confirmpassword+"','"+Login_Type+"')";                       
                          String insert=db.Insert(sql);
                          out.println(insert);
                          
                          resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Sign Up Succesful')");
                           out.println("location='Login.jsp'");
                           out.println("</script>");
        
                          
                                  
                      }
                      catch(Exception ex)
                      {
                          out.println(ex.toString());
                      }
                      
                  }
                  else
                  {
                      resp.setContentType("text/html");
                           out.println("<script type=\"text/javascript\">");
                           out.println("alert('Password and Confirm password are not same')");
                           out.println("location='Login.jsp'");
                           out.println("</script>");
                   }
                  }
              }
        
         
         
    }
}