/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shubzz
 */
public class userHome extends HttpServlet {
    
   
    Connection cn=null;
    Statement st=null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
         PrintWriter out=resp.getWriter();
         String event = req.getParameter("submit");
         
         out.println(event);
         
         
         
        Database db = new Database();
        String result = db.Connectdb();
        out.println(result);
        
        
        if(event.equals("Shop Now"))
        {
            resp.sendRedirect("UserPages/userVegetable.jsp");
        }
        
        
        
         if(event.equals("Buy Now"))
        {
            resp.sendRedirect("UserPages/userFruit.jsp");
        }
         
         
         
          if(event.equals("Add to Cart"))
        {
            resp.sendRedirect("UserPages/userCart.jsp");
        }
        
           
    }
}
